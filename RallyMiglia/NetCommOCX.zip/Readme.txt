7/12/2002

The OLEAUT32.DLL file that had been included in this setup seems
to corrupt certain systems.  This should not happen (it should not
be installed unless absent).  However, there may be a bug in
InstallShield that causes a problem.  Thus, I have removed this file
from the Setup files.

I cannot test this very satisfactorily, so let me know if there are problems.

Special Note:  The Setup.pdf file found here IS NOT an Adobe Acrobat document!
It is used by InstallShield during the install process.

Dick